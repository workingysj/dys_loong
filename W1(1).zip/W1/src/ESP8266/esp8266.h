#ifndef __ESP8266_H
#define __ESP8266_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ls1c102.h"


char* esp8266_check_cmd(char *str);
char esp8266_send_cmd(char *cmd,char *ack,uint16_t waittime);
void esp8266_init(void);
void esp8266_send_data(char *cmd);
void esp8266_Publish(void);

#ifdef __cplusplus
}
#endif

#endif

