#ifndef _TIMER_H
#define _TIMER_H

#ifdef __cplusplus
extern "C" {
#endif

void timer_interrupt(void);
void timer_irq(void);


#ifdef __cplusplus
}
#endif

#endif // _TIMER_H

