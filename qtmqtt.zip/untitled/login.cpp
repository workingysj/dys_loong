﻿#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);

    this->w=new Widget;

    connect(this,&login::sendData,w,&Widget::receiveData);
    connect(w,&Widget::sendData,this,&login::receiveData);
}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()
{
    ProductKey=ui->lineEdit->text();
    DeviceName=ui->lineEdit_2->text();
    DeviceSecret=ui->lineEdit_3->text();

    QString senddata=ProductKey+","+DeviceName+","+DeviceSecret;
    emit sendData(senddata);
}


void login::receiveData(QString data)
{
    if(data=="connect")
    {
        this->hide();
        w->show();
    }
}
