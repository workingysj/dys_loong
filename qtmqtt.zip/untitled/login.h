﻿#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include "widget.h"
namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();
private slots:
    void on_pushButton_clicked();
    void receiveData(QString);
signals:
    void sendData(QString);
private:
    Ui::login *ui;

    QString ProductKey;
    QString DeviceName;
    QString DeviceSecret;

    Widget *w;
};

#endif // LOGIN_H
