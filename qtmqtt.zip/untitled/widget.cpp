﻿#include "widget.h"
#include "ui_widget.h"
#include <QTableWidget>
#include <QStandardItem>
#include <QMessageAuthenticationCode>
#include <QJsonObject>
#include <QJsonDocument>
#include <QTime>
#include <QTimer>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    cameras = QCameraInfo::availableCameras();//获取可用摄像头设备列表
    int index = cameras.size();//判断可用的摄像头有几个
    for(int i=0;i<index;i++)
    {
        if(cameras.at(i).isNull() == false)
        {
            qDebug() << "有效摄像头:" << cameras.at(i).description();//摄像头的设备名称
            ui->comboBox->addItem(cameras.at(i).description()); //将摄像头添加到UI界面摄像头列表中
        }
    }


    sender = new QUdpSocket(this);
    reciver = new QUdpSocket(this);
    reciver->bind(12345,QUdpSocket::ReuseAddressHint);
    QObject::connect(reciver,SIGNAL(readyRead()),this,SLOT(onReadyRead()));

/*
    ① 通过QCameraInfo类的defaultCamera获取摄像头信息，以QCameraInfo对象保存
    ② 将包含有摄像头信息的QCameraInfo对象，传入QCamera构造函数，构造一个QCamera对象，该对象就能管理刚才获取到的摄像头了
    ③ QCamera对象，管理的摄像头，拍摄到的图片，必须交给QAbstructVideoSurface对象去处理
        QAbstructVideoSurface这个类是一个纯虚类，必须继承过后重写里面的纯虚方法
*/
//    QCameraInfo info = QCameraInfo::defaultCamera();
//    camera = new QCamera(info);
//    AbstractVideoSurface* surface = new AbstractVideoSurface(this);//图像处理类
//    camera->setViewfinder(surface);//将camera拍摄到的图片交给AbstractVideoSurface类对象里面的present函数进行处理
    //表格
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
     ui->tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
     ui->tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//     ui->tableWidget->horizontalHeader()->hide();
     ui->tableWidget->verticalHeader()->hide();
     ui->tableWidget_2->verticalHeader()->hide();
     ui->tableWidget_2->setItem(0,0,new QTableWidgetItem(QStringLiteral("风机")));
     ui->tableWidget_2->setItem(1,0,new QTableWidgetItem(QStringLiteral("水泵")));
     ui->tableWidget_2->setItem(2,0,new QTableWidgetItem(QStringLiteral("卷帘")));
     QTableWidgetItem *item[4];
     QTableWidgetItem *unit[4];
     for(int i=0;i<4;i++)
     {
         item[i]=new QTableWidgetItem;
     }
     item[0]->setText(QStringLiteral("空气温度"));
     item[1]->setText(QStringLiteral("空气湿度"));
//     item[2]->setText(QStringLiteral("土壤温度");
     item[2]->setText(QStringLiteral("土壤湿度"));
     item[3]->setText(QStringLiteral("光照强度"));
//     item[5]->setText("二氧化碳浓度");
     for(int i=0;i<4;i++)
     {
         ui->tableWidget->setItem(i,0,item[i]);
     }

     for(int i=0;i<4;i++)
     {
         unit[i]=new QTableWidgetItem;
     }
     for(int i=0;i<4;i++)
     {
         unit[0]->setText(QStringLiteral("℃"));
         unit[1]->setText(QStringLiteral("%rh"));
         unit[2]->setText(QStringLiteral("%rh"));
         unit[3]->setText(QStringLiteral("Lux"));
     }
     for(int i=0;i<4;i++)
     {
         ui->tableWidget->setItem(i,2,unit[i]);
     }
//      connect(m_standardItemModel, SIGNAL(dataChanged(const QModelIndex &, const QModelIndex &)), ui->tableView, SLOT(update()));

     //时间

     current_time = new QTime;
     current_timer =new QTimer;
     *current_time = QTime::currentTime();
     current_timer->start(30);
     ui ->label_3->setText(current_time->toString("hh:mm:ss"));
     connect(current_timer,SIGNAL(timeout()),this,SLOT(now_time_SLOT()));






}

Widget::~Widget()
{
    delete ui;
}
void Widget::rcvImage(QImage image)
{
    QPixmap pic = QPixmap::fromImage(image);
    pic = pic.scaled(ui->label->size());
    ui->label->setPixmap(pic);

    QImage img = pic.toImage();

/*
    writeDatagram里面，数据最多是一个QByteArray，所以，我们现在要想办法，把QImage存入QByteArray(或者转换成QByteArray)
*/
/*
    整个转换逻辑如下：
    QImage 里面有一个方法叫做 save，可以将QImage保存到 QIODevice的对象里面去
    QIODevice有一个派生类叫做 QBuffer，也就是说QIamge::save可以做到将QImage保存到一个QBuffer里面去
    QBuffer的构造函数，支持传入一个QByteArray，作为QBuffer的缓存区
        也就是意味着：写入，保存进入QBuffer的数据，实际上是保存到了 QByteArray里面来
*/
    QByteArray arr;
    QBuffer buf(&arr);//将arr作为buf缓存区
    img.save(&buf,"JPG");//将image保存到buf里面去，实际上就是保存到buf的缓存区arr里面去
    sender->writeDatagram(arr,QHostAddress::Broadcast,12345);
    if(reciver->isOpen()){
        reciver->close();
    }
}

void Widget::onReadyRead()
{
//  读取图片的时候，一样的道理,要将QByteArray里面的数据，作为QImage读取
/*
    有一个类叫做 QImageReader，里面有一个方法叫做read
    QImageReader的构造函数，支持传入一个QIODevice，能传入QIODeviec，就等于说是传入了一个QByteArray
*/
    int size = reciver->pendingDatagramSize();//获取图片尺寸
    QByteArray arr;
    arr.resize(size);//将arr适应图片大小

    reciver->readDatagram(arr.data(),size);//QByteArray的data()方法，获取首地址
    // 读取数据，保存到arr里面

    QBuffer buf(&arr);
    QImageReader reader(&buf);
    QImage image = reader.read();

    QPixmap pic = QPixmap::fromImage(image);
    ui->label->setPixmap(pic);

}

void Widget::on_pushButton_clicked()
{
    countine+=1;
    if(countine==2)
    {
        ui->label->clear();
        camera->stop();
        delete(camera);
    }
    int index = cameras.size();//判断可用的摄像头有几个
    for(int i=0;i<index;i++)
    {
        if(cameras.at(i).description()==ui->comboBox->currentText())
        {
            info = cameras.at(i);
        }
    }

    camera = new QCamera(info);
    AbstractVideoSurface* surface = new AbstractVideoSurface(this);//图像处理类
    camera->setViewfinder(surface);//将camera拍摄到的图片交给AbstractVideoSurface类对象里面的present函数进行处理
    QObject::connect(surface,SIGNAL(sndImage(QImage)),this,SLOT(rcvImage(QImage)));
    camera->start();
//    qDebug<<ui->comboBox->currentText();

}

void Widget::on_pushButton_2_clicked()
{
    countine=0;
    ui->label->clear();
    camera->stop();
    delete(camera);
}

void Widget::brokerConnected()
{
    qDebug() << "Connected!";
    if(m_client->state() == QMqttClient::Connected){
        ui->label_2->setText("connect");
        QString data="connect";
        emit sendData(data);
        m_client->subscribe(QMqttTopicFilter("/sys/k1hy4vdYkO5/qtmqtt/thing/service/property/set"));
        connect(m_client,SIGNAL(messageReceived(QByteArray,QMqttTopicName)),this,SLOT(receiveMess(QByteArray,QMqttTopicName)));
    }
}

void Widget::receiveMess(const QByteArray &message, const QMqttTopicName &topic)
{
   QString content;
   content = QDateTime::currentDateTime().toString() + QLatin1Char('\n');
   content += QLatin1String(" Received Topic: ") + topic.name() + QLatin1Char('\n');
   content += QLatin1String(" Message: ") + message + QLatin1Char('\n');
   qDebug() << content;
   QJsonDocument jsonResponse = QJsonDocument::fromJson(message);
   QJsonObject jsonObject = jsonResponse.object();
   QJsonObject itemsObject = jsonObject["items"].toObject();

   // 更新变量值
   if(itemsObject.contains("LightLux"))
   {
       lightLuxValues.append(itemsObject["LightLux"].toObject()["value"].toDouble());
   }
   if(itemsObject.contains("airHumidity"))
   {
       airHumidityValues.append(itemsObject["airHumidity"].toObject()["value"].toDouble());
   }
   if(itemsObject.contains("airTemp"))
   {
       airTempValues.append(itemsObject["airTemp"].toObject()["value"].toDouble());
   }
   if(itemsObject.contains("soilHumidity"))
   {
       soilHumidityValues.append(itemsObject["soilHumidity"].toObject()["value"].toDouble());
   }
//   soilTemperatureValues.append(itemsObject["soilTemperature"].toObject()["value"].toDouble());
//   co2Values.append(itemsObject["co2"].toObject()["value"].toDouble());

   double motor=itemsObject["motor"].toObject()["value"].toDouble();
   double fan=itemsObject["fan"].toObject()["value"].toDouble();
   double pump=itemsObject["pump"].toObject()["value"].toDouble();
   if(motor==1)
   {
       ui->tableWidget_2->setItem(2,1,new QTableWidgetItem(QStringLiteral("开启")));
   }
   else
   {
       ui->tableWidget_2->setItem(2,1,new QTableWidgetItem(QStringLiteral("关闭")));
   }
   if(fan==1)
   {
     ui->tableWidget_2->setItem(0,1,new QTableWidgetItem(QStringLiteral("开启")));
   }
   else
   {
       ui->tableWidget_2->setItem(0,1,new QTableWidgetItem(QStringLiteral("关闭")));
   }
   if(pump==1)
   {
     ui->tableWidget_2->setItem(1,1,new QTableWidgetItem(QStringLiteral("开启")));
   }
   else
   {
       ui->tableWidget_2->setItem(1,1,new QTableWidgetItem(QStringLiteral("关闭")));
   }
   //ui显示
   if(!airTempValues.isEmpty())
   {
       ui->tableWidget->setItem(0, 1, new QTableWidgetItem(QString::number(airTempValues.last())));
   }
   if(!airHumidityValues.isEmpty())
   {
       ui->tableWidget->setItem(1, 1, new QTableWidgetItem(QString::number(airHumidityValues.last())));
   }
   if(!soilHumidityValues.isEmpty())
   {
       ui->tableWidget->setItem(2, 1, new QTableWidgetItem(QString::number(soilHumidityValues.last())));
   }
   if(!lightLuxValues.isEmpty())
   {
       ui->tableWidget->setItem(3, 1, new QTableWidgetItem(QString::number(lightLuxValues.last())));
   }
//   ui->tableWidget->setItem(2, 1, new QTableWidgetItem(QString::number(soilTemperatureValues.last())));
//   ui->tableWidget->setItem(5, 1, new QTableWidgetItem(QString::number(co2Values.last())));
//   ui->tableWidget->setModel(m_standardItemModel);
   ui->tableWidget->viewport()->update();
   // 输出所有存储的值
   qDebug() << "LightLux values:" << lightLuxValues;
//   qDebug() << "SoilTemperature values:" << soilTemperatureValues;
//   qDebug() << "CO2 values:" << co2Values;
   qDebug() << "AirHumidity values:" << airHumidityValues;
   qDebug() << "AirTemp values:" << airTempValues;
   qDebug() << "SoilHumidity values:" << soilHumidityValues;
   qDebug() << "motor values:" <<motor;
   qDebug() << "fan values:" <<fan;
   qDebug() << "pump values:" <<pump;
}

void Widget::now_time_SLOT()
{
    *current_time = current_time->addMSecs(30);
    ui->label_3->setText(current_time->toString("hh:mm:ss"));
}

void Widget::receiveData(QString data)
{
    QStringList result = data.split(',');


    //mqtt
    m_client = new QMqttClient(this);
//    m_strProductKey="k1hy4vdYkO5";  //需要跟阿里云Iot平台一致;
//    m_strDeviceName="qtmqtt";   //需要跟阿里云Iot平台一致;
//    m_strDeviceSecret="0695313d99fb9b6917dfaf998f85929e";   //需要跟阿里云平台一致

    m_strProductKey="k1hy4vdYkO5";  //需要跟阿里云Iot平台一致;
    m_strDeviceName="qtmqtt";   //需要跟阿里云Iot平台一致;
    m_strDeviceSecret="0695313d99fb9b6917dfaf998f85929e";   //需要跟阿里云平台一致

    m_strRegionId="cn-shanghai";

    m_strPubTopic = "/sys/" + m_strProductKey + "/" + m_strDeviceName + "/thing/event/property/post";//发布topic
    m_strSubTopic = "/sys/" + m_strProductKey + "/" + m_strDeviceName + "/thing/service/property/set";//订阅topic
    m_strTargetServer = m_strProductKey + ".iot-as-mqtt." + m_strRegionId + ".aliyuncs.com";//域名

    m_client->setHostname(m_strTargetServer);
    m_client->setPort(1883);

    QString clientId="abcdefg";         //表示客户端ID，建议使用设备的MAC地址或SN码，64字符内。
    QString signmethod = "hmacsha1";    //加密方式
    QString message ="clientId"+clientId+"deviceName"+m_strDeviceName+"productKey"+m_strProductKey;

    m_client->setUsername(m_strDeviceName + "&" + m_strProductKey);
    m_client->setClientId(clientId + "|securemode=3,signmethod=" + signmethod + "|");
    m_client->setPassword(QMessageAuthenticationCode::hash(message.toLocal8Bit(),
                                                           m_strDeviceSecret.toLocal8Bit(),
                                                           QCryptographicHash::Sha1).toHex());
    m_client->connectToHost();//连接阿里云


    connect(m_client, &QMqttClient::connected, this, &Widget::brokerConnected);

}
