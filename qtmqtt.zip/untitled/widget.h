﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

#include <QCamera>
#include <QCameraInfo>
#include "abstractvideosurface.h"
#include <QImage>
#include <QUdpSocket>
#include <QBuffer>
#include <QImageReader>

#include <qmqttclient.h>
#include <QtMqtt/qmqttclient.h>
#include <QStandardItem>
#include <QTableWidgetItem>
#include <QTime>
#include <QTimer>
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public slots:
    void rcvImage(QImage);
    void onReadyRead();
    void brokerConnected();
    void receiveMess(const QByteArray &, const QMqttTopicName &);
    void now_time_SLOT();
    void receiveData(QString);
private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
signals:
    void sendData(QString);

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::Widget *ui;

//    QStandardItemModel* m_standardItemModel = new QStandardItemModel(6,2);
//    QTableWidgetItem *item[6];
    //摄像头相关
    QCamera* camera;
    QUdpSocket* sender;
    QUdpSocket* reciver;
    QList<QCameraInfo> cameras;
    QCameraInfo info;
    int countine=0;


    //mqtt相关
    QMqttClient *m_client;
    QString m_strProductKey;
    QString m_strDeviceName;
    QString m_strDeviceSecret;
    QString m_strRegionId;
    QString m_strPubTopic;
    QString m_strSubTopic;
    QString m_strTargetServer;

    //传感器数据
    QList<double> lightLuxValues;
//    QList<double> soilTemperatureValues;
//    QList<double> co2Values;
    QList<double> airHumidityValues;
    QList<double> airTempValues;
    QList<double> soilHumidityValues;
//    auto motor;
//    bool fan;
//    bool pump;

    QTime *current_time;
    QTimer *current_timer;

};
#endif // WIDGET_H
