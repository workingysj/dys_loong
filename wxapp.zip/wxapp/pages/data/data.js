// index.js
import mqtt from'../../utils/mqtt.js';
import * as echarts from '../../ec-canvas/echarts.js';
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');

function initChart(canvas, width, height) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);
  var option = {
    xAxis: {
      type: 'category',
      data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    },
    yAxis: {
      type: 'value'
    },
    series: [{
      name: "temperture",
      data: [820, 932, 901, 934, 1290, 1330, 1320],
      type: 'line'
    }
    // ,{
    //   name: "humidity",
    //   data: [],
    //   type: 'line'
    // },{
    //   name: "illumination",
    //   data: [],
    //   type: 'line'
    // },{
    //   name: "soilhumidity",
    //   data: [],
    //   type: 'line'
    // }
  ]
  };
  chart.setOption(option);
  return chart;
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ec: {
      onInit: initChart
    },
    open:false,
    mark:0,
    newmark:0,
    istoright: false,// 默认关闭 只能左向右划

    showchart:false,
    showdata:false,
    //table相关
    //标题
    temp_columns: [
      { label: '温度', prop: 'value'},
      { label: '时间', prop: 'time'},
    ],
    hum_columns: [
      { label: '湿度', prop: 'value'},
      { label: '时间', prop: 'time'},
    ],
    illu_columns: [
      { label: '光照', prop: 'value'},
      { label: '时间', prop: 'time'},
    ],
    soil_columns: [
      { label: '土壤湿度', prop: 'value'},
      { label: '时间', prop: 'time'},
    ],
    //自定义配置项
    setting: {
      tableRadius: 0, // 表格圆角
      tableOutBorder: '', // 表格外边框
      tableInBorder: '2rpx solid #ebeef5', // 表格内边框
      tableInBorderLevel: 'false', // 表格内只显示水平边框
      theadHeight: 75, // 表头的高度
      theadAlign: '', // 表头的字体对齐方式
      theadColor: '', // 表头的字体颜色
      theadBgColor: '', // 表头的背景色
      theadFontSize: '', // 表头的字体大小
      theadFontWeight: '', // 表头的字体粗细
      tbodyHeight: '175',  // 表格 tbody 的高度, 用于垂直滚动
      tbodyAlign: '', // 表格行的的字体对齐方式
      tbodyColor: '', // 表格行的字体颜色
      tbodyBgColor: '', // 表格行的背景色
      tbodyFontSize: '', // 表格行的字体大小
      tbodyFontWeight: '', // 表格行的字体粗细
      trHeight: 60, // 表格行 tr 的高度
      stripe: '#fdf5e6' // #fafafa #f5f5f5 #fdf5e6 #fff8dc #f0f9eb
    },
    //数据值
    //用于存放数组的对象
    result:{airTemp:[],
            airHumidity:[],
            LightLux:[],
            soilHumidity:[],
            fan:0,
            pump:0,
            motor:0},
    //节点一
    items:[],
    //aliyun连接相关
    client:null,//记录重连的次数
      reconnectCounts:0,//MQTT连接的配置
      options:{
        protocolVersion: 4, //MQTT连接协议版本
        clean: false,
        reconnectPeriod: 1000, //1000毫秒，两次重新连接之间的间隔
        connectTimeout: 30 * 1000, //1000毫秒，两次重新连接之间的间隔
        resubscribe: true, //如果连接断开并重新连接，则会再次自动订阅已订阅的主题（默认true）
        clientId: '',
        password: '',
        username: '',
      },

      aliyunInfo: {
        productKey: 'k1hy4vdYkO5', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceName: 'wxapp', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceSecret: '4f9b6808c8fee7f73eb164d509295c2c', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        regionId: 'cn-shanghai', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        // pubTopic: '/k1hy4vdYkO5/+/thing/event/property/post', //发布消息的主题
        subTopic: '/sys/k1hy4vdYkO5/wxapp/thing/service/property/set', //订阅消息的主题
      },
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad:function(){
    //that = this;
    var that=this;
    let clientOpt = aliyunOpt.getAliyunIotMqttClient({
      productKey: that.data.aliyunInfo.productKey,
      deviceName: that.data.aliyunInfo.deviceName,
      deviceSecret: that.data.aliyunInfo.deviceSecret,
      regionId: that.data.aliyunInfo.regionId,
      port: that.data.aliyunInfo.port,
    });

    console.log("get data:" + JSON.stringify(clientOpt));
    let host = 'wxs://' + clientOpt.host;
    
    this.setData({
      'options.clientId': clientOpt.clientId,
      'options.password': clientOpt.password,
      'options.username': clientOpt.username,
    })
    console.log("this.data.options host:" + host);
    console.log("this.data.options data:" + JSON.stringify(this.data.options));

    //访问服务器
    this.data.client = mqtt.connect(host, this.data.options);

    this.data.client.on('connect', function (connack) {
      wx.showToast({
        title: '连接成功'
      })
      console.log("连接成功");
    })

    //接收消息监听
    this.data.client.on("message", function (topic, payload) {
      console.log(" 收到 topic:" + topic + " , payload :" + payload);
      let temporary_var=JSON.parse(payload).items;
      let result = that.data.result;
      // console.log(temporary_var);
      for(var key in temporary_var)
      {
        if(key=="fan"||key=="motor"||key=="pump")
        {
          result[key]=temporary_var[key].value;
        }
        else
        {
          result[key].push(temporary_var[key]);
        }
      }
      that.setData({
        result:result,
      })
      // console.log(that.data.result.temperature1);
      // let keys=temporary_var.map(function(item) {
      //   return item.key;
      // });
      // let targetkey="temperature1";
      // let keyindex=keys.indexOf(targetkey);
      // //温度
      // if(keyindex !== -1) 
      // {
      //   let temparr=that.data.temperature1;
      //   temparr.push(temporary_var.temperature1);
      //   that.setData({
      //     temperature1:temparr,
      //   });
      // }
      
    })

    //服务器连接异常的回调
    that.data.client.on("error", function (error) {
      console.log(" 服务器 error 的回调" + error)

    })
    //服务器重连连接异常的回调
    that.data.client.on("reconnect", function () {
      console.log(" 服务器 reconnect的回调")

    })
    //服务器连接异常的回调
    that.data.client.on("offline", function (errr) {
      console.log(" 服务器offline的回调")
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  gotopage:function(e){
    this.setData({
      showdata:true,
      showchart:false
    });
  },

  onTabItemTap(item){
    if(item.text=='数据')
    {
      this.setData({
        showdata:false,
        showchart:false
      });
    }
  },

  showchart:function(e)
  {
    // let xdata = this.result["temperature"].time;
    // let series = this.result["temperature"].value;
    this.setData({
      showchart:true,
      showdata:false,
      // 'option.xAxis.data': xdata,
      // 'option.series[0].data': series
    })
  }
  
})