#include "stm32f10x.h"    
#include "usart.h"
#include "stdio.h"
#include "string.h"
#include "esp8266.h"
#include "fan.h"
#include "DHT11.h"

extern float temperature;
extern float humidity;
extern int locker;

//const char* WIFI ="Duck";
//const char* WIFIASSWORD="123456789000";
//const char* ClintID="k1hy4vdYkO5.node2|securemode=2\\,signmethod=hmacsha256\\,timestamp=1719828125483|";
//const char* username="node2&k1hy4vdYkO5";
//const char* passwd="710b7c91dd3899be4f65ee02d8db77484900df50a8edd6a8e51b24cbdd4d2611";
//const char* mqttHostUrl="iot-06z00jjb7sefxzd.mqtt.iothub.aliyuncs.com";
const char* pubtopic_transfer="/k1hy4vdYkO5/node2/user/update";
const char* pubtopic_post="/sys/k1hy4vdYkO5/node2/thing/event/property/post";


// ����MS������ʱ������������ֲʱ���ⲿ�ļ�������
static void Delay_ms(uint32_t ms)
{
    uint32_t i = 0;
    while (ms--)
    {
        i = 12000;
        while (i--);
    }
}

void ESP8266_Init(void)
{
	printf("AT+RST\r\n");//����
	Delay_ms(2000);
	
	printf("AT+CWMODE=1\r\n"); //Stationģʽ
	Delay_ms(1000);
	
	printf("AT+CWJAP=\"Duck\",\"123456789000\"\r\n"); //�����ȵ�
	Delay_ms(1000);
	
	printf("AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n");		//������
	Delay_ms(1000);					//�ӳ�
	
	printf("AT+MQTTUSERCFG=0,1,\"Null\",\"node2&k1hy4vdYkO5\",\"710b7c91dd3899be4f65ee02d8db77484900df50a8edd6a8e51b24cbdd4d2611\",0,0,\"\"\r\n");//�û���Ϣ����
	Delay_ms(1000);
	
	printf("AT+MQTTCLIENTID=0,\"k1hy4vdYkO5.node2|securemode=2\\,signmethod=hmacsha256\\,timestamp=1719828125483|\"\r\n");//�û���Ϣ����
	Delay_ms(1000);
	
	printf("AT+MQTTCONN=0,\"iot-06z00jjb7sefxzd.mqtt.iothub.aliyuncs.com\",1883,1\r\n"); //���ӷ�����
	Delay_ms(2000);	
	
//	printf("AT+MQTTSUB=0,\"%s\",1\r\n",subtopic); //������Ϣ
//	Delay_ms(1000);

}

//���ƶ˷�����Ϣ������STM32��Ӧ���ƶ�����
void ESP_Publish(void)
{
		temperature = DHT11_GetTemperature(GPIOB, GPIO_Pin_10);  // ��ȡDHT11�¶�ֵ, ע�⣬DHT11�ľ��ȣ�С��������Ч
		humidity =  DHT11_GetHumidity(GPIOB, GPIO_Pin_10);       // ��ȡDHT11ʪ��ֵ, ע�⣬DHT11�ľ��ȣ�С��������Ч
		printf("AT+MQTTPUB=0,\"/sys/k1hy4vdYkO5/node2/thing/event/property/post\",\"{\\\"params\\\":{\\\"airTemp\\\":%4.2f\\,\\\"airHumidity\\\":%4.2f}}\",0,0\r\n",temperature,humidity);
		Delay_ms(400);  
		//printf("AT+MQTTPUB=0,\"/k1hy4vdYkO5/node2/user/update\",\"{\\\"params\\\":{\\\"airTemp\\\":%4.2f\\,\\\"airHumidity\\\":%4.2f}}\",0,0\r\n",temperature,humidity);
		//Delay_ms(400);  
		if(temperature >= 27.5)
		{
			printf("AT+MQTTPUB=0,\"/sys/k1hy4vdYkO5/node2/thing/event/property/post\",\"{\\\"params\\\":{\\\"fan\\\":1}}\",0,0\r\n");
			Delay_ms(400);
			//printf("AT+MQTTPUB=0,\"/k1hy4vdYkO5/node2/user/update\",\"{\\\"params\\\":{\\\"fan\\\":1}}\",0,0\r\n");
			//Delay_ms(400);
			FAN_ON;
			//GPIO_SetBits(FAN_GPIO,FAN_PIN);
			Delay_ms(400);
		}
		else if(temperature < 27.5)
		{
			printf("AT+MQTTPUB=0,\"/sys/k1hy4vdYkO5/node2/thing/event/property/post\",\"{\\\"params\\\":{\\\"fan\\\":0}}\",0,0\r\n");
			Delay_ms(400);
			//printf("AT+MQTTPUB=0,\"/k1hy4vdYkO5/node2/user/update\",\"{\\\"params\\\":{\\\"fan\\\":0}}\",0,0\r\n");
			//Delay_ms(400);
			FAN_OFF;
			//GPIO_ResetBits(FAN_GPIO,FAN_PIN);
			Delay_ms(400);
		}
} 
